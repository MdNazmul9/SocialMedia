1. Tweets
    -> User Permissions
        -> Creating
            -> Text
            -> Image -> Media Storage Server
        -> Delete
        -> Retweeting
            -> Read only serializer
            -> Create only serializer
        -> Liking or Unliking

2. Users
    -> Register
    -> Login
    -> Logout
    -> Profile
        -> Image?
        -> Text?
        -> Follow Button
    -> Feed
        -> User's feed only?
        -> User + who they follow?

3. Following / Followers


Next Steps:
- Large File Uploads for Images ~ Dive into AWS
- Notifications
- Direct Messages / Private Inboxes ~ Chat x Channels
- Explore -> parse & filter for hashtags
